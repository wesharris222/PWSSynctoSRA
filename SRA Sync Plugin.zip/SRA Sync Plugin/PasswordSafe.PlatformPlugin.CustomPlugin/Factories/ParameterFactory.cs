using PasswordServices.Plugins.Abstractions.Models;
using PasswordServices.Plugins.Common;

namespace PasswordSafe.PlatformPlugin.SRASync
{
    internal class ParameterFactory : ParameterValueFactory
    {

        /// <summary>
        /// The default port.
        /// </summary>
        public const int DefaultPort = 0;  // Update by correct value of default Port# if required

        /// <summary>
        /// The default connection timeout.
        /// </summary>
        public const int DefaultConnectionTimeout = 15;  // Update using correct value for your managed system


        public ParameterFactory(ActionParameters args) : base(args)
        { }

    }
}
