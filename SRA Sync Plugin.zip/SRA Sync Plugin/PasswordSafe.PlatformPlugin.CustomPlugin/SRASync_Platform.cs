using System.Composition;
using PasswordServices.Plugins.Abstractions.Models;

namespace PasswordSafe.PlatformPlugin.SRASync
{

    /// <summary>
    /// This class is responsible for setting the actions available on the platform.
    /// </summary>
    [Export(typeof(IPlugin))]
    [PluginMetadata("SRASync", "24.1.1.1", "Sync a managed account to SRA", "ParrotGreen", "62E0E2F2-2845-4547-B6A3-28A38FAD631A")]
    public sealed class SRASyncPlatform : PluginBase, IPlugin
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="SRASyncPlatform"/> class.
        /// </summary>
        /// <param name="change_functionalaccount_credentials_action">Change_FunctionalAccount_Credentials action.</param>
        /// <param name="change_managedaccount_credentials_using_functionalaccount_action">Change_ManagedAccount_Credentials_Using_FunctionalAccount action.</param>
        /// <param name="change_managedaccount_credentials_using_self_action">Change_ManagedAccount_Credentials_Using_Self action.</param>
        /// <param name="discovery_accounts_action">Discovery_Accounts action.</param>
        /// <param name="verify_functionalaccount_credentials_action">Verify_FunctionalAccount_Credentials action.</param>
        /// <param name="verify_managedaccount_credentials_action">Verify_ManagedAccount_Credentials action.</param>
        [ImportingConstructor]
        public SRASyncPlatform(
            [Import("Change_FunctionalAccount_Credentials")] Change_FunctionalAccount_Credentials_Action change_functionalaccount_credentials_action
            , [Import("Change_ManagedAccount_Credentials_Using_FunctionalAccount")] Change_ManagedAccount_Credentials_Using_FunctionalAccount_Action change_managedaccount_credentials_using_functionalaccount_action
            , [Import("Change_ManagedAccount_Credentials_Using_Self")] Change_ManagedAccount_Credentials_Using_Self_Action change_managedaccount_credentials_using_self_action
            , [Import("Discovery_Accounts")] Discovery_Accounts_Action discovery_accounts_action
            , [Import("Verify_FunctionalAccount_Credentials")] Verify_FunctionalAccount_Credentials_Action verify_functionalaccount_credentials_action
            , [Import("Verify_ManagedAccount_Credentials")] Verify_ManagedAccount_Credentials_Action verify_managedaccount_credentials_action
        )
        {  
            this.ImplementedActions.Add(change_functionalaccount_credentials_action);  
            this.ImplementedActions.Add(change_managedaccount_credentials_using_functionalaccount_action);  
            this.ImplementedActions.Add(change_managedaccount_credentials_using_self_action);  
            this.ImplementedActions.Add(discovery_accounts_action);  
            this.ImplementedActions.Add(verify_functionalaccount_credentials_action);  
            this.ImplementedActions.Add(verify_managedaccount_credentials_action);        
        }
    }
}
