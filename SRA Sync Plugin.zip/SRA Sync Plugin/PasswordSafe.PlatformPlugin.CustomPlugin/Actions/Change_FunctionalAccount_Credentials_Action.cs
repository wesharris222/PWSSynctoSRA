//-----------------------------------------------------------------------
// <copyright file="Change_FunctionalAccount_Credentials_Action.cs" company="ParrotGreen">
// Copyright (c) ParrotGreen. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Composition;
using PasswordServices.Plugins.Abstractions;
using PasswordServices.Plugins.Abstractions.Enumerations;
using PasswordServices.Plugins.Abstractions.Exceptions;
using PasswordServices.Plugins.Abstractions.Models;

namespace PasswordSafe.PlatformPlugin.SRASync
{

    /// <summary>
    /// This class is responsible for Change_FunctionalAccount_Credentials action.
    /// </summary>
    [Export("Change_FunctionalAccount_Credentials")]
    public class Change_FunctionalAccount_Credentials_Action : PluginActionBase
    {
        private const EPluginActionType SupportedActionType = EPluginActionType.Change_FunctionalAccount_Credentials;


        /// <summary>
        /// Initializes a new instance of the <see cref="Change_FunctionalAccount_Credentials_Action"/> class.
        /// </summary>
        [ImportingConstructor]
        public Change_FunctionalAccount_Credentials_Action()
        {  }

        /// <inheritdoc/>
        public override bool IsMatch(EPluginActionType actionType)
        {
            return actionType == SupportedActionType;
        }

        /// <inheritdoc/>
        public override PluginActionDetails GetActionDetails()
        {
            var requiredArgs = new PluginActionDetails(SupportedActionType, true);

            requiredArgs.RequiredParameters.Add(EActionParameter.ManagedSystem_HostsByOption);  // string[]
            requiredArgs.RequiredParameters.Add(EActionParameter.ManagedSystem_Port);  // int?
            requiredArgs.RequiredParameters.Add(EActionParameter.ManagedSystem_Timeout);   // int?


            // Uncomment required parameters below
            // --- Functional Account parameters
            // requiredArgs.RequiredParameters.Add(EActionParameter.FunctionalAccount_AccountName_only);             // string
            // requiredArgs.RequiredParameters.Add(EActionParameter.FunctionalAccount_CredentialsCurrent_Password);  // string
            // requiredArgs.RequiredParameters.Add(EActionParameter.FunctionalAccount_CredentialsNew_Password);      // string
            // --- Managed Account parameters
            // requiredArgs.RequiredParameters.Add(EActionParameter.ManagedAccount_AccountName_only);                // string
            // requiredArgs.RequiredParameters.Add(EActionParameter.ManagedAccount_CredentialsCurrent_Password);     // string
            // requiredArgs.RequiredParameters.Add(EActionParameter.ManagedAccount_CredentialsNew_Password);         // string

            return requiredArgs;
        }

        /// <inheritdoc/>
        public override PluginActionResult ExecuteAction(ActionParameters parameters)
        {
            var pluginActionResult = new PluginActionResult(parameters);
            
            try
            {
                if (parameters.ActionType != SupportedActionType)
                {
                    pluginActionResult.FinishAction(
                        EPluginActionResult.NotSupported,
                        EPluginActionErrorCode.WrongParameters,
                        $"Action '{SupportedActionType}' does not process '{parameters.ActionType}'");
                    return pluginActionResult;
                }
                var paramFactory = new ParameterFactory(parameters);

                // Uncomment required parameters below
                // --- Functional Account parameters
                // string functionalAccountName = paramFactory.Get_String_Value(EActionParameter.FunctionalAccount_AccountName_only, true, GlobalConstants.ParameterError_FunctionalAccountNameIsEmptyString);
                // string currentPasswordFA = paramFactory.Get_String_Value(EActionParameter.FunctionalAccount_CredentialsCurrent_Password, true, GlobalConstants.ParameterError_FunctionalAccountCurrentPasswordIsNotDefined);
                // string newPasswordFA = paramFactory.Get_String_Value(EActionParameter.FunctionalAccount_CredentialsNew_Password, true, GlobalConstants.ParameterError_FunctionalAccountNewPasswordIsNotDefined);
                // --- Managed Account parameters
                // string managedAccountName = paramFactory.Get_String_Value(EActionParameter.ManagedAccount_AccountName_only, true, GlobalConstants.ParameterError_ManagedAccountNameIsEmptyString);
                // string currentPasswordMA = paramFactory.Get_String_Value(EActionParameter.ManagedAccount_CredentialsCurrent_Password, true, GlobalConstants.ParameterError_ManagedAccountCurrentPasswordIsNotDefined);
                // string newPasswordMA = paramFactory.Get_String_Value(EActionParameter.ManagedAccount_CredentialsNew_Password, true, GlobalConstants.ParameterError_ManagedAccountNewPasswordIsNotDefined);


                // --- Hosts
                string[] hosts = paramFactory.Get_HostsByOptions_Value();

                int portNumber = paramFactory.Get_Port_Parameter(ParameterFactory.DefaultPort);
                int timeout = paramFactory.Get_Timeout_Parameter(ParameterFactory.DefaultConnectionTimeout);

                foreach (string host in hosts)
                {
                    if (pluginActionResult.IsFinished && pluginActionResult.Result == EPluginActionResult.Success) break;
                    else if (pluginActionResult.IsFinished)
                    {
                        pluginActionResult = new PluginActionResult(pluginActionResult);
                    }
                   
                    pluginActionResult.Dump = $"Change_FunctionalAccount_Credentials action on SRASync system: Server={host}:{portNumber}";
                    
                    // Add your code in this place and remove NotImplementedException below.
                    // Completed action must set a status of the PluginActionResult object by calling method FinishAction(<EPluginActionResult>,<EPluginActionErrorCode>,<string>) with proper arguments.
                    //       Samples of the action results: ;
                    //            pluginActionResult.FinishAction(EPluginActionResult.Success, EPluginActionErrorCode.NoError, "<Your message>");  // success
                    //             or
                    //            pluginActionResult.FinishAction(EPluginActionResult.Failed, EPluginActionErrorCode.AuthenticationFailed, "<Your message>");  // failed  with authentication error code
                    //             or 
                    //            pluginActionResult.FinishAction(EPluginActionResult.Failed, EPluginActionErrorCode.Timeout, "Communication timeout");  // failed because of timeout
                    //
                    // To add one or more informational messages to the action result set Dump property with a new message: 
                    //            pluginActionResult.Dump="your message"; 
                    // 
                    // DiscoveryAccounts action must return list of discovered accounts in PluginActionResult object. 
                    // Add new record to the PluginActionResult's property OutputData with Key=OutputDataKey.DiscoveredAccounts and Value=<list of discovered accounts names>.  
                    //       Sample of code: 
                    //            List<string> discoveredAccounts = new List<string>();
                    //            .......your code to discover accounts.....
                    //            pluginActionResult.FinishAction(EPluginActionResult.Success, EPluginActionErrorCode.NoError, $"{discoveredAccounts.Count} accounts were discovered");
                    //            pluginActionResult.OutputData.Add(OutputDataKey.DiscoveredAccounts, discoveredAccounts);

                    throw new NotImplementedException("Missing implementation code in the class Change_FunctionalAccount_Credentials_Action");
 
                }
            }
            catch (NotImplementedException ex)
            {
                pluginActionResult.Dump = $"NotImplementedException: {ex.Message}";
                pluginActionResult.FinishAction(
                        EPluginActionResult.Terminated,
                        EPluginActionErrorCode.Exception,
                        GlobalConstants.ActionFailedSeeLog
                        );
            }
            catch (WrongParameterException ex)
            {
                pluginActionResult.Dump = $"Parameter error: {ex.Message}";
                pluginActionResult.FinishAction(
                        EPluginActionResult.Terminated,
                        EPluginActionErrorCode.WrongParameters,
                        GlobalConstants.ActionFailedSeeLog
                        );
            }
            catch (Exception ex)
            {
                pluginActionResult.Dump = $"Exception: {ex.Message}";
                pluginActionResult.FinishAction(
                        EPluginActionResult.Terminated,
                        EPluginActionErrorCode.Exception,
                        GlobalConstants.ActionFailedSeeLog
                        );
            }
            finally
            {
                if (!pluginActionResult.IsFinished)
                {
                    string message = $"Action has not been finished. Result={pluginActionResult?.Result}";
                    pluginActionResult.FinishAction(EPluginActionResult.Unknown, EPluginActionErrorCode.Exception, message);
                }
            }
            return pluginActionResult;
        }
    }
}
